if [ -e "$HOME/FotoSploit" ]; then
	
bash ~/FotoSploit/Etical
apt -y update
apt -y upgrade
apt -y install python python2 python3
apt -y install php
apt -y install ssh
apt -y install wget
chmod 777 ~/FotoSploit
chmod 777 ~/Etical
cp -rv ~/FotoSploit/FotoSploit $PREFIX/bin
rm -rf ~/FotoSploit/install.sh
echo "Finished"
echo "Usage: bash FotoSploit"
exit
else
	sleep 3
	echo "(*) porfavor mueveme a HOME"
	echo "(*) Es importante para que el BOT corra bien"

	exit

fi
